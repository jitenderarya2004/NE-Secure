package com.example.ne_secure

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
